
registerBlockType( 'contentviews/grid1', { title: 'Grid Post' } );
registerBlockType( 'contentviews/list1', { title: 'List Post' } );
registerBlockType( 'contentviews/pinterest', { title: 'Pinterest' } );
registerBlockType( 'contentviews/collapsible', { title: 'Collapsible Post' } );
registerBlockType( 'contentviews/scrollable', { title: 'Scrollable Post' } );
registerBlockType( 'contentviews/timeline', { title: 'Post Timeline' } );
registerBlockType( 'contentviews/onebig1', { title: 'Big Post 1' } );
registerBlockType( 'contentviews/onebig2', { title: 'Big Post 2' } );
registerBlockType( 'contentviews/overlay1', { title: 'Post Overlay 1' } );
registerBlockType( 'contentviews/overlay2', { title: 'Post Overlay 2' } );
registerBlockType( 'contentviews/overlay3', { title: 'Post Overlay 3' } );
registerBlockType( 'contentviews/overlay4', { title: 'Post Overlay 4' } );
registerBlockType( 'contentviews/overlay5', { title: 'Post Overlay 5' } );
registerBlockType( 'contentviews/overlay6', { title: 'Post Overlay 6' } );
registerBlockType( 'contentviews/overlay7', { title: 'Post Overlay 7' } );
registerBlockType( 'contentviews/overlay8', { title: 'Post Overlay 8' } );