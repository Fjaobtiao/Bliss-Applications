<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

echo implode( "\n", $fields_html );
